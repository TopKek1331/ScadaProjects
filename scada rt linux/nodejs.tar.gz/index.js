﻿// var XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
// var JSZip = require("jszip");
// Element = 'undefined';

const argv = require("minimist")(process.argv.slice(2));
const fs = require("./fs");
const stripBom = require("strip-bom");
const opentype = require("opentype.js");
const http = require("http");
const Path = require("path");
const util = require("util");

XMLHttpRequest = require("xmlhttprequest").XMLHttpRequest;
Element = "undefined";
JSZip = require("jszip");
const Stimulsoft = require("./stimulsoft.reports.js");
const ServerConfig = {
	port: argv.port || 9615,
	exemplars: argv.exemplars || 0,
	mplc: argv.mplc || "http://127.0.0.1",
	fonts: argv.fonts || "fonts",
	log: argv.log,
};
const months = [
	"Jan",
	"Feb",
	"Mar",
	"Apr",
	"May",
	"Jun",
	"Jul",
	"Aug",
	"Sep",
	"Oct",
	"Nov",
	"Dec",
];

function mplc_url(id, method) {
	return ServerConfig.mplc + (id == 0 ? "" : "/" + id) + method;
}
function ping_url(id) {
	return mplc_url(id, "/Methods/PingReports");
}
function reg_url(id) {
	return mplc_url(id, "/Methods/RegisterBuilder");
}
function finish_url(id) {
	return mplc_url(id, "/Methods/ReportBuilded");
}
function report_data_url(id) {
	return mplc_url(id, "/Methods/GetReportData");
}

function pad(n) {
	return n < 10 ? "0" + n.toString(10) : n.toString(10);
}
function timestamp() {
	let d = new Date();
	let time = [
		pad(d.getHours()),
		pad(d.getMinutes()),
		pad(d.getSeconds()),
	].join(":");
	return [d.getDate(), months[d.getMonth()], time].join(" ");
}

var console_log;
if (ServerConfig.log) {
	try {
		let all = fs.createWriteStream(ServerConfig.log, { flags: "a" });
		console_log = (d) => {
			all.write(util.format("%s: %j\n", timestamp(), d));
		};
	} catch (err) {
		console_log(err);
	}
} else {
	console_log = function (d) {
		console.log(util.format("%s: %j\n", timestamp(), d));
	};
}

let font = opentype.loadSync(__dirname + "/Roboto-Black.ttf");
Stimulsoft.System.NodeJs.useWebKit = false;
Stimulsoft.System.NodeJs.initialize();
Stimulsoft.Base.StiFontCollection.addOpentypeFont(font);
try {
	let fonts = fs.readdirSync(ServerConfig.fonts, "utf8");
	for (let i = 0; i < fonts.length; i++) {
		console_log(fonts[i]);
		let font = opentype.loadSync(items[i]);
		Stimulsoft.Base.StiFontCollection.addOpentypeFont(font);
	}
} catch (err) {
	console_log(err);
}

function addTimestamp(str) {
	let d = new Date();
	p = (number) => {
		return (number < 10 ? "0" : "") + number;
	};
	return (
		str +
		"_" +
		util.format(
			"%d_%s_%s_%s_%s_%s",
			d.getFullYear(),
			p(d.getMonth() + 1),
			p(d.getDate()),
			p(d.getHours()),
			p(d.getMinutes()),
			p(d.getSeconds())
		)
	);
}

console_log("Stimulsoft Reports loaded");

class ReportProcessor {
	constructor() {
		this.building = false;
		this.reportsQueue = [];

		this.ReportBuilder = new Stimulsoft.Report.StiReport();

		this.htmlSettings = new Stimulsoft.Report.Export.StiHtmlExportSettings();
		this.htmlService = new Stimulsoft.Report.Export.StiHtmlExportService();

		this.pdfSettings = new Stimulsoft.Report.Export.StiPdfExportSettings();
		this.pdfService = new Stimulsoft.Report.Export.StiPdfExportService();

		this.excelSettings = new Stimulsoft.Report.Export.StiExcelExportSettings();
		this.excelService = new Stimulsoft.Report.Export.StiExcel2007ExportService();

		let rp = this;
		this.ReportBuilder.onBeginProcessData = function (event, callback) {
			event.request.reportId = rp.report.id;
			//console_log(event);
		};
		this.ReportBuilder.onEndProcessData = function (event, callback) {
			console_log(event);
		};
		this.tmplExt = ".json";
	}

	renderError(e) {
		if (!this.report) return;
		let message = e;
		if (!e && !e.message) message = e.message;
		this.ReportBuilder.hasError = true;

		this.error(message);
	}

	finished(report) {
		let data = {
			success: true,
			reportId: report.id,
			path: report.userPath,
			filename: report.filename,
		};
		console_log(`Report ${report} finished. ${JSON.stringify(data)}`);
		this.send(data);
	}
	send(data) {
		if (this.connect) {
			this.connect.send(JSON.stringify(data));
			this.connect = null;
		}
		this.report = null;
		this.renderNext();
	}
	error(message) {
		console_log(
			`Error build report ${JSON.stringify(this.report)} msg:  ${message}`
		);
		if (!this.report) return;
		let data = {
			success: false,
			reportId: this.report.id,
			error: `${message}`,
		};
		this.send(data);
	}
	getTemplate() {
		let templatepath = Path.join(
			this.report.templatesDir,
			this.report.template || this.report.name + this.tmplExt
		);
		return fs.readFileSync(templatepath, "utf8");
	}
	saveReportToHtml(filepath) {
		let textWriter = new Stimulsoft.System.IO.TextWriter();
		let htmlTextWriter = new Stimulsoft.Report.Export.StiHtmlTextWriter(
			textWriter
		);
		this.htmlService.exportTo(
			this.ReportBuilder,
			htmlTextWriter,
			this.htmlSettings
		);
		let resultHtml = textWriter.getStringBuilder().toString();
		fs.writeFileSync(filepath, resultHtml);
	}
	saveReportToExcel(filepath) {
		let stream = new Stimulsoft.System.IO.MemoryStream();
		this.excelService.exportTo(
			this.ReportBuilder,
			stream,
			this.excelSettings
		);
		let data = stream.toArray();
		let buffer = new Buffer(data, "utf-8");
		fs.writeFileSync(filepath, buffer);
	}
	saveReportToPdf(filepath) {
		let stream = new Stimulsoft.System.IO.MemoryStream();
		this.pdfService.exportTo(this.ReportBuilder, stream, this.pdfSettings);
		let data = stream.toArray();
		let buffer = new Buffer(data, "utf-8");
		fs.writeFileSync(filepath, buffer);
	}
	onEndRender() {
		try {
			if (this.ReportBuilder.hasError) return;
			let report = this.report;
			let file = Path.parse(report.filepath);
			let userPath = report.reportPath;
			if (file.ext == "") {
				file.name = addTimestamp(report.name);
				file.ext = report.ext || ".pdf";
				file.base = file.name + file.ext;
				file.dir = report.filepath;
				userPath = Path.join(userPath, file.base);
			}
			if (!fs.existsSync(file.dir)) {
				fs.mkdirSync(file.dir, "0666", true);
			}
			report.filepath = Path.join(file.dir, file.base);
			report.filename = file.base;
			report.userPath = userPath;
			switch (file.ext.substring(1)) {
				case "html":
					this.saveReportToHtml(report.filepath);
					break;
				case "pdf":
					this.saveReportToPdf(report.filepath);
					break;
				case "xlsx":
					this.saveReportToExcel(report.filepath);
					break;
				default:
					this.saveReportToPdf(report.filepath);
			}
			this.finished(report);
		} catch (e) {
			this.error(e.message);
		}
	}
	renderReport() {
		try {
			let report = this.report;
			this.connectTo(report.url);
			let reportProcessor = this;
			let template = this.getTemplate(report);
			let reportBuilder = this.ReportBuilder;
			reportBuilder.dictionary.databases.clear();
			reportBuilder.load(template);
			console_log("Template '" + report.name + "' loaded");
			reportBuilder.hasError = false;
			Stimulsoft.System.StiError.showError = function (e, showForm) {
				reportProcessor.renderError(e, report);
			};
			let scadaDatabase = reportBuilder.dictionary.databases.list.find(
				function (db, i, arr) {
					return db.getStiTypeName == "ScadaDatabase";
				}
			);
			if (scadaDatabase) {
				scadaDatabase.masterPlcHost = report_data_url(
					report.responseTo
				);
			}
			let dataSources = reportBuilder.dataSources.list;
			let lua_items = dataSources.find(function (ds, i, arr) {
				return ds.tableName == "lua_items";
			});
			let saveReport = function () {
				reportProcessor.onEndRender();
			};
			if (lua_items) {
				lua_items
					.connectAsync(null, true)
					.try(function () {
						reportBuilder.renderAsync(saveReport);
					})
					.catch(function (message) {
						reportProcessor.error(message);
					});
			} else {
				reportBuilder.renderAsync(saveReport);
			}
		} catch (e) {
			this.error(e.message, this.report.id);
		}
	}
	renderNext() {
		if (this.reportsQueue.length == 0) return;
		if (this.report) return;
		this.report = this.reportsQueue.shift();
		this.renderReport();
	}
	connectTo(url) {
		this.connect = new XMLHttpRequest();
		this.connect.open("post", url, true);
		this.connect.setRequestHeader("Content-Type", "application/json");
	}
	addReport(report) {
		console_log(
			"Add report '" +
				report.name +
				"' from " +
				mplc_url(report.responseTo, "")
		);
		report.url = finish_url(report.responseTo);
		let path = Path.isAbsolute(report.reportPath)
			? report.reportPath
			: Path.join(report.reportsDir, report.reportPath);
		report.filepath = Path.normalize(path);
		this.reportsQueue.push(report);
	}
}

function accept(req, res) {
	res.setHeader("Access-Control-Allow-Origin", "*");
	res.setHeader("Cache-Control", "no-cache");

	let request = "";
	let response = function (data) {
		res.end(JSON.stringify(data));
	};
	req.on("data", function (data) {
		request += data;
	});
	req.on("end", function () {
		try {
			let report = JSON.parse(request.toString());
			reportProcessor.addReport(report);
			response({ success: true });
			reportProcessor.renderNext();
		} catch (e) {
			response({ success: false, error: e.message });
		}
	});
}

class MonitorConnection {
	// this.exemplars - array of connection status for each exemplar mplc
	// 0 - not connected
	// 1 - waiting response
	// 2 - connected
	constructor() {
		this.exemplars = [];
		for (let i = 0; i <= ServerConfig.exemplars; i++) {
			this.exemplars[i] = 0;
		}
	}
	start() {
		this.regService();
		let monitor = this;
		this.check = setInterval(() => {
			monitor.ping();
		}, 60 * 1000);
		this.connect = setInterval(() => {
			monitor.regService();
		}, 10 * 1000);
	}
	stop() {
		clearInterval(this.check);
		clearInterval(this.connect);
	}
	update(i, response, message) {
		try {
			let data = JSON.parse(response);
			this.exemplars[i] = data.code == 0 ? 2 : 0;
			console_log(message + mplc_url(i, ""));
			console_log("Mplc response: " + response);
		} catch (e) {
			this.exemplars[i] = 0;
			console_log(response);
		}
	}
	ping() {
		for (let i = 0; i < this.exemplars.length; i++) {
			if (this.exemplars[i] != 2) continue;
			this.exemplars[i] = 1;
			let url = ping_url();
			let monitor = this;
			let connect = new XMLHttpRequest();
			connect.open("post", url, true);
			connect.setRequestHeader("Content-Type", "application/json");
			connect.timeout = 1000;
			connect.onload = () => {
				monitor.update(i, connect.responseText, "Ping ");
			};
			connect.ontimeout = (e) => {
				monitor.update(i, connect.responseText, "");
			};
			connect.onerror = (e) => {
				monitor.update(i, connect.responseText, "");
			};
			connect.send(
				JSON.stringify({
					level: 0x4,
					message: "Ping from ReportBuildService",
				})
			);
		}
	}
	regService() {
		for (let i = 0; i < this.exemplars.length; i++) {
			if (this.exemplars[i] != 0) continue;
			this.exemplars[i] = 1;
			let monitor = this;
			let url = reg_url(i);
			let connect = new XMLHttpRequest();
			connect.open("post", url, true);
			connect.setRequestHeader("Content-Type", "application/json");
			connect.timeout = 1000;
			connect.onload = () => {
				monitor.update(i, connect.responseText, "Register in ");
			};
			connect.ontimeout = (e) => {
				monitor.update(i, connect.responseText, "");
			};
			connect.onerror = (e) => {
				monitor.update(i, connect.responseText, "");
			};
			connect.send(
				JSON.stringify({ url: "http://127.0.0.1:" + ServerConfig.port })
			);
		}
	}
}

const reportProcessor = new ReportProcessor();
const monitor = new MonitorConnection();

http.createServer(accept).listen(ServerConfig.port);
console_log("Server started on port: " + ServerConfig.port);
monitor.start();
console_log("Start monitoring");
