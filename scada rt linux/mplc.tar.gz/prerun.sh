if ! [ -e /lib64/ld-linux-x86-64.so.2 ]; then
	mkdir -p /lib64
	ln -s /lib/ld-linux-x86-64.so.2 /lib64/ld-linux-x86-64.so.2 
fi